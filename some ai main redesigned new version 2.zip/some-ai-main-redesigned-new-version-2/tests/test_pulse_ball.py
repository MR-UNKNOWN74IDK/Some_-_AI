"""PulseBall: touchable audio-reactive ball + pause button (needs PyQt6, runs offscreen)."""
import os
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
import pytest
from PyQt6.QtWidgets import QApplication


@pytest.fixture(scope="session")
def qapp():
    return QApplication.instance() or QApplication(["--platform", "offscreen"])


def test_volume_is_clamped_and_emitted(qapp):
    from ui import PulseBall
    b = PulseBall()
    seen = []
    b.volume_changed.connect(seen.append)
    b.set_volume(140, emit=True)
    assert b.volume() == 100
    b.set_volume(-5, emit=True)
    assert b.volume() == 0 and seen[-1] == 0


def test_pause_button_toggles_and_emits(qapp):
    from ui import PulseBall
    b = PulseBall()
    seen = []
    b.pause_toggled.connect(seen.append)
    b._btn.click()
    assert b.is_paused() and seen == [True] and b._btn.text() == "Resume"
    b._btn.click()
    assert not b.is_paused() and seen == [True, False] and b._btn.text() == "Pause"


def test_paused_ball_goes_quiet(qapp):
    from ui import PulseBall
    b = PulseBall()
    b.set_paused(True)
    b.set_audio_level(1.0)
    for _ in range(30):
        b._tick()
    assert max(b._bars) < 0.02


def test_tap_while_speaking_requests_stop(qapp):
    from PyQt6.QtCore import QPointF, Qt, QEvent
    from PyQt6.QtGui import QMouseEvent
    from ui import PulseBall
    b = PulseBall()
    b.resize(340, 400)
    seen = []
    b.stop_requested.connect(lambda: seen.append(1))
    pos = QPointF(170, 120)

    def click():
        b.mousePressEvent(QMouseEvent(QEvent.Type.MouseButtonPress, pos, pos, Qt.MouseButton.LeftButton,
                                      Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier))
        b.mouseReleaseEvent(QMouseEvent(QEvent.Type.MouseButtonRelease, pos, pos, Qt.MouseButton.LeftButton,
                                        Qt.MouseButton.NoButton, Qt.KeyboardModifier.NoModifier))
    b.set_state("IDLE")
    click()
    assert seen == []          # quiet: a tap only peeks at the volume
    b.set_state("SPEAKING")
    click()
    assert seen == [1]         # speaking: a tap cuts it off
